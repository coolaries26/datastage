#!/bin/sh
. ./varcreds.config

varIdesConn=$IDES_DBConn
varIdesUser=$IDES_User
varIdesPwd=$IDES_Password

varIdesamConn=$IDESAM_DBConn
varIdesamUser=$IDESAM_User
varIdesamPwd=$IDESAM_Password

varTopConn=$TOP_DBConn
varTopUser=$TOP_User
varTopPwd=$TOP_Password

varCmdwConn=$CMDW_DBConn
varCmdwUser=$CMDW_User
varCmdwPwd=$CMDW_Password

varSCConn=$SC_DBConn
varSCUser=$SC_User
varSCPwd=$SC_Password

varISTConn=$IST_DBConn
varISTUser=$IST_User
varISTPwd=$IST_Password

varCisfConn=$CISF_DBConn
varCisfUser=$CISF_User
varCisfPwd=$CISF_Password

varOdsConn=$ODS_DBConn
varOdsUser=$ODS_User
varOdsPwd=$ODS_Password

varIDMConn=$IDM_DBConn
varIDMPwd=$IDM_Password
varIDMUser=$IDM_User
varIDMSchema=$IDM_Schema_Var

current_dir=$(pwd)

sed -e "s/\(TOP_DB_ParamSet.\$TOPDB=\).*/\1$varTopConn/g" -e "s/\(TOP_DB_ParamSet.\$TOPUSR=\).*/\1$varTopUser/g"  -e "s/\(TOP_DB_ParamSet.\$TOPPWD=\).*/\1$varTopPwd/g" -e "s/\(CMDW_DB_ParamSet.ConnectionString=\).*/\1$varCmdwConn/g" -e "s/\(CMDW_DB_ParamSet.Username=\).*/\1$varCmdwUser/g"  -e "s/\(CMDW_DB_ParamSet.Password=\).*/\1$varCmdwPwd/g"  -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g"  -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_45328_Params.txt > $current_dir/parmfiles/RTC_45328_ParamsUpd.txt

sed -e "s/\(IDESAM_DB_ParamSet.ConnectionString=\).*/\1$varIdesamConn/g" -e "s/\(IDESAM_DB_ParamSet.Username=\).*/\1$varIdesamUser/g" -e "s/\(IDESAM_DB_ParamSet.Password=\).*/\1$varIdesamPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_45328_FtsQ_Params.txt > $current_dir/parmfiles/RTC_45328_FtsQ_ParamsUpd.txt

sed -e "s/\(IDES_DB_ParamSet.ConnectionString=\).*/\1$varIdesConn/g" -e "s/\(IDES_DB_ParamSet.Username=\).*/\1$varIdesUser/g" -e "s/\(IDES_DB_ParamSet.Password=\).*/\1$varIdesPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_45911_Params.txt > $current_dir/parmfiles/RTC_45911_ParamsUpd.txt

sed -e "s/\(CISF_DB_ParamSet.ConnectionString=\).*/\1$varCisfConn/g" -e "s/\(CISF_DB_ParamSet.Username=\).*/\1$varCisfUser/g" -e "s/\(CISF_DB_ParamSet.Password=\).*/\1$varCisfPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_45988_Params.txt > $current_dir/parmfiles/RTC_45988_ParamsUpd.txt

sed -e "s/\(IDESAM_DB_ParamSet.ConnectionString=\).*/\1$varIdesamConn/g" -e "s/\(IDESAM_DB_ParamSet.Username=\).*/\1$varIdesamUser/g" -e "s/\(IDESAM_DB_ParamSet.Password=\).*/\1$varIdesamPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_46058_Params.txt > $current_dir/parmfiles/RTC_46058_ParamsUpd.txt

sed -e "s/\(IDESAM_DB_ParamSet.ConnectionString=\).*/\1$varIdesamConn/g" -e "s/\(IDESAM_DB_ParamSet.Username=\).*/\1$varIdesamUser/g" -e "s/\(IDESAM_DB_ParamSet.Password=\).*/\1$varIdesamPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_46491_Params.txt > $current_dir/parmfiles/RTC_46491_ParamsUpd.txt

sed -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_46639_Params.txt > $current_dir/parmfiles/RTC_46639_ParamsUpd.txt

sed -e "s/\(ODS_DB_ParamSet.ConnectionString=\).*/\1$varOdsConn/g" -e "s/\(ODS_DB_ParamSet.Username=\).*/\1$varOdsUser/g" -e "s/\(ODS_DB_ParamSet.Password=\).*/\1$varOdsPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_52767_Params.txt > $current_dir/parmfiles/RTC_52767_ParamsUpd.txt

sed -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parameters_55514_temp.txt > $current_dir/parameters_55514.txt

sed -e "s/\(IDES_DB_ParamSet.ConnectionString=\).*/\1$varIdesConn/g" -e "s/\(IDES_DB_ParamSet.Username=\).*/\1$varIdesUser/g" -e "s/\(IDES_DB_ParamSet.Password=\).*/\1$varIdesPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_58541_Params.txt > $current_dir/parmfiles/RTC_58541_ParamsUpd.txt

sed -e "s/\(IDES_DB_ParamSet.ConnectionString=\).*/\1$varIdesConn/g" -e "s/\(IDES_DB_ParamSet.Username=\).*/\1$varIdesUser/g" -e "s/\(IDES_DB_ParamSet.Password=\).*/\1$varIdesPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_58542_Params.txt > $current_dir/parmfiles/RTC_58542_ParamsUpd.txt

sed -e "s/\(IDESAM_DB_ParamSet.ConnectionString=\).*/\1$varIdesamConn/g" -e "s/\(IDESAM_DB_ParamSet.Username=\).*/\1$varIdesamUser/g" -e "s/\(IDESAM_DB_ParamSet.Password=\).*/\1$varIdesamPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_59675_Params.txt > $current_dir/parmfiles/RTC_59675_ParamsUpd.txt

sed -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IDM_DB_ParamSet.ConnectionString=\).*/\1$varIDMConn/g" -e "s/\(IDM_DB_ParamSet.Username=\).*/\1$varIDMUser/g" -e "s/\(IDM_DB_ParamSet.Password=\).*/\1$varIDMPwd/g" -e "s/\(IDM_Schema_Var=\).*/\1$varIDMSchema/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_67125_Params.txt > $current_dir/parmfiles/RTC_67125_ParamsUpd.txt

sed -e "s/\(TOP_DB_ParamSet.\$TOPDB=\).*/\1$varTopConn/g" -e "s/\(TOP_DB_ParamSet.\$TOPUSR=\).*/\1$varTopUser/g"  -e "s/\(TOP_DB_ParamSet.\$TOPPWD=\).*/\1$varTopPwd/g" -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_73635_Params.txt > $current_dir/parmfiles/RTC_73635_ParamsUpd.txt

sed -e "s/\(SC_DB_ParamSet.ConnectionString=\).*/\1$varSCConn/g" -e "s/\(SC_DB_ParamSet.Username=\).*/\1$varSCUser/g" -e "s/\(SC_DB_ParamSet.Password=\).*/\1$varSCPwd/g" -e "s/\(IST_DB_ParamSet.ConnectionString=\).*/\1$varISTConn/g" -e "s/\(IST_DB_ParamSet.Username=\).*/\1$varISTUser/g" -e "s/\(IST_DB_ParamSet.Password=\).*/\1$varISTPwd/g" $current_dir/parmfiles/RTC_73636_Params.txt > $current_dir/parmfiles/RTC_73636_ParamsUpd.txt