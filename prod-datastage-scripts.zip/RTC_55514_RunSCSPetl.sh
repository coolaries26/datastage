#!/bin/sh

# Script: runSCSPetl.sh
#                                          
# This script invokes DS job in TOP application.
# 
######################################################################
#
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

#
######################################################################
# Initiate variables
######################################################################
#
ACTION=$1
DSPROJECT=DI_DatastageDefault-diwasetl-build
DSPATH=$DSHOME/bin
JOBLOG=/var/datastage/scripts/runSCSPetl.log
DATADIR=/var/datastage/data
NOTIFYALERT=bautisjo@ph.ibm.com,moraleri@ph.ibm.com,magnoan@ph.ibm.com,dieza@ph.ibm.com,joseas@mx1.ibm.com,barreto@mx1.ibm.com,Manuel.Velasco@ibm.com,kartnair@in.ibm.com,lwylilwy@cn.ibm.com,nabaroy1@in.ibm.com,nachi312@in.ibm.com,cghchudl@cn.ibm.com,jacky.liu@cn.ibm.com
BPMSG="Bad param entered; job terminated"
ETL=Seller_Profile_TOP_Feed_ETL
RECIPIENT=bautisjo@ph.ibm.com,moraleri@ph.ibm.com,magnoan@ph.ibm.com,dieza@ph.ibm.com,joseas@mx1.ibm.com,barreto@mx1.ibm.com,Manuel.Velasco@ibm.com,kartnair@in.ibm.com,lwylilwy@cn.ibm.com,nabaroy1@in.ibm.com,nachi312@in.ibm.com,cghchudl@cn.ibm.com,jacky.liu@cn.ibm.com
echo $DSPATH
#
# start DS varaibles
LIMIT=99999
RUNFAIL='RUN FA'
CRASHED='UNKNOW'
STOPPED='STOPPE'
RUNNING='RUNNIN'
RUNOK='RUN OK'
# end DS varaibles
#
######################################################################
# Function - send alert email
######################################################################
sendAlert() 
{           
  tail $JOBLOG | mail -s "$1" "$2" 
}
######################################################################
# Function - doDSJob
######################################################################
doDSJob()
{
#
echo 'check job sts...'
# check DS job status
echo 'job name....'
echo $JOBNAME
  runstat=`$DSPATH/dsjob -jobinfo $DSPROJECT $JOBNAME | grep "Job Status" | cut -c14-19`
#
  if [[ $runstat = $RUNNING ]]; then
    echo `date` ">>> $DSPROJECT $ETL: $JOBNAME currently running, try later" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: $JOBNAME currently running alert" $NOTIFYALERT
    exit 2
  fi
#
# reset job if necessary
  if [[ $runstat = $RUNFAIL || $runstat = $STOPPED || $runstat = $CRASHED ]]; then
    $DSPATH/dsjob -run -mode RESET $DSPROJECT $JOBNAME
  fi
#
  if [[ $waitFlag == "1" ]]; then
    $DSPATH/dsjob -run -jobstatus -warn $LIMIT $JOBPARAM $DSPROJECT $JOBNAME
  else
    # $DSPATH/dsjob -run -warn $LIMIT $JOBPARAM $DSPROJECT $JOBNAME
	$DSPATH/dsjob -run -warn $LIMIT -paramfile /var/datastage/scripts/parameters_55514.txt $JOBPARAM $DSPROJECT $JOBNAME
  fi
  rc=$?
  return $rc
#
}
######################################################################
# Function - perform readiness check
######################################################################
doCheck()
{
# checkp if data from previous load has been processed
#
  JOBNAME=SCSP_CTRL_CHK
  statusFile=$DATADIR/SCSP_CTRL.txt
  p=" -param "
  p1="STATUS_FILE=$statusFile"
  JOBPARAM=`echo $p $p1`
  waitFlag=1
  doDSJob 
  rc=$?
  if [[ $rc -gt 2 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: $JOBNAME job run error" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: $JOBNAME job run error" $NOTIFYALERT
    exit
  fi
#
# result from check is stored in status control file
#
  if [[ -s $statusFile ]]; then
    status=`cat ${statusFile}`
  else 
    echo `date` ">>> $DSPROJECT $ETL: status file not found" 
    exit
  fi
#
echo $status
  if [[ $status == 1 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: status 1, proceed to process" 
  else
    echo `date` ">>> $DSPROJECT $ETL: status <> 1, $status"
  fi
}
#
######################################################################
# Function - perform Seller Profile ETL
######################################################################
doSCSP()
{
# checkp if data from previous load has been processed
#
  JOBNAME=SCSP_CTRL_CHK
  statusFile=$DATADIR/SCSP_CTRL.txt
  p=" -param "
  p1="STATUS_FILE=$statusFile"
  JOBPARAM=`echo $p $p1`
  waitFlag=1
  doDSJob 
  rc=$?
  if [[ $rc -gt 2 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: $JOBNAME job run error!!!" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: $JOBNAME job run error" $NOTIFYALERT
    exit
  fi
#
# result from check is stored in status control file
#
  if [[ -s $statusFile ]]; then
    status=`cat ${statusFile}`
  else 
    echo `date` ">>> $DSPROJECT $ETL: status file not found" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: status file not found" $NOTIFYALERT
    exit
  fi
#
##RNB: Add this only for skipping initial check: 
#status=1;
  if [[ $status == 1 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: status 1, proceed to process" >>$JOBLOG
#
    JOBNAME=SCSP_ETL_SEQ
    p=" -param "
    p1="RECIPIENT=$RECIPIENT"
    JOBPARAM=`echo $p $p1`
    waitFlag=0
    doDSJob 
    rc=$?
    if [[ $rc -gt 2 ]]; then
      echo `date` ">>> $DSPROJECT $ETL: $JOBNAME job run error" >>$JOBLOG
      sendAlert "$DSPROJECT $ETL: $JOBNAME job run error" $NOTIFYALERT
      exit
    fi
  else
    echo `date` ">>> $DSPROJECT $ETL: status 0, no go, process terminated" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: status 0, no go, process terminated" $NOTIFYALERT
  fi
#
  return
}
#
######################################################################
# Function - perform Seller Profile ETL
######################################################################
doExtract()
{
#
  JOBNAME=SCSP_EXT_SEQ
  p=" -param "
  p1="PARAM1="
  JOBPARAM=
  waitFlag=0
  doDSJob 
  rc=$?
  if [[ $rc -gt 2 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: $JOBNAME job run error" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: $JOBNAME job run error" $NOTIFYALERT
    exit
  fi
#
  return
}
#
######################################################################
# Function - perform Seller Profile ETL
######################################################################
doStaging()
{
#
  JOBNAME=SCSP_STG_SEQ
  p=" -param "
  p1="PARAM1="
  JOBPARAM=
  waitFlag=0
  doDSJob 
  rc=$?
  if [[ $rc -gt 2 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: $JOBNAME job run error" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: $JOBNAME job run error" $NOTIFYALERT
    exit
  fi
#
  return
}
#
######################################################################
# Function - perform Seller Profile ETL
######################################################################
doFeed()
{
#
  JOBNAME=SCSP_FEED_SEQ
  p=" -param "
  p1="PARAM1="
  JOBPARAM=
  waitFlag=0
  doDSJob 
  rc=$?
  if [[ $rc -gt 2 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: $JOBNAME job run error" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: $JOBNAME job run error" $NOTIFYALERT
    exit
  fi
#
  return
}
#
######################################################################
# Function - perform extract from source and target
######################################################################
doCtrlIns()
{
#
  JOBNAME=SCSP_CTRL_INS
  p=" -param "
  p1="PARAM1="
  JOBPARAM=
  waitFlag=0
  doDSJob 
  rc=$?
  if [[ $rc -gt 2 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: $JOBNAME job run error" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: $JOBNAME job run error" $NOTIFYALERT
    exit
  fi
#
  return
}
######################################################################
# Function - perform extract from source and target
######################################################################
doCtrlUpd()
{
#
  JOBNAME=SCSP_CTRL_UPD
  p=" -param "
  p1="STATUSCD=$STATUSCD"
  JOBPARAM=`echo $p $p1`
  waitFlag=0
  doDSJob 
  rc=$?
  if [[ $rc -gt 2 ]]; then
    echo `date` ">>> $DSPROJECT $ETL: $JOBNAME job run error" >>$JOBLOG
    sendAlert "$DSPROJECT $ETL: $JOBNAME job run error" $NOTIFYALERT
    exit
  fi
#
  return
}
######################################################################
# start of main logic
######################################################################
echo `date` ">>> $DSPROJECT SalesConnect ETL: Starting $ACTION" >>$JOBLOG
#
case "$ACTION" in
  CHECK)
    doCheck
  ;;
  SCSP)
    doSCSP
  ;;
  CTRLINS)
    doCtrlIns
  ;;
  CTRLUPD)
    STATUSCD=$2
    if [[ $STATUSCD = "" ]]; then
      STATUSCD=1
    fi
    doCtrlUpd
  ;;
  EXTRACT)
    doExtract
  ;;
  STAGING)
    doStaging
  ;;
  FEED)
    doFeed
  ;;
  TEST)
  echo "test:" $2
  ;;
  *)
    echo `date` ">>> $DSPROJECT SalesConnect: $1 $BPMSG" >>$JOBLOG
    exit 1
esac
#
