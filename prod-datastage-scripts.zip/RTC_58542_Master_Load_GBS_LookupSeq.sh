#!/bin/sh

# Initialize environment variables to use the Datastage commands
                         #
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

jobsDir=$1
. $1/varcreds.config
ds_project=$Datastage_Project-$Datastage_User-build
#s_project=DI_DatastageDefault-2_0

echo "Connected to project: "$ds_project
echo "Running RTC_58542_Master_BU_Lookup job..."

#  Invoke Datastage job.
$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_58542_ParamsUpd.txt $ds_project RTC_58542_Master_Load_GBS_Lookup > /dev/null  2>&1
RETURNCODE=$?

# Evaluating the return code                  #
if [  $RETURNCODE = 1 -o $RETURNCODE = 2  ]
	then
	echo "Job RTC_58542_Master_BU_Lookup completed successfully"
else
echo "Job RTC_58542_Master_Lookup aborting with Return Code :"$RETURNCODE
exit 3
fi;
