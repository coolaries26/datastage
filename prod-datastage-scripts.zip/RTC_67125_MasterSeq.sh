#!/bin/sh

# Initialize environment variables to use the Datastage commands                                 #
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

jobsDir=$1
. $1/varcreds.config

#The next line is on use when running the job in production or pre-production
ds_project=$Datastage_Project-$Datastage_User-build

#The next line is used when running the using in Development
#ds_project=DI_DatastageDefault-2_0

echo "Connected to project: "$ds_project
echo "Running RTC_67125_Master job..."

#  Invoke Datastage job.
#$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_67125_ParamsUpd.txt $ds_project RTC_67125_IDM_to_Contacts_Master > /dev/null 2>&1
$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_67125_ParamsUpd.txt $ds_project RTC_67125_IDM_to_Contacts_Master > /dev/null 2>&1
RETURNCODE=$?

# Evaluating the return code                                                                       #
if [  $RETURNCODE = 1 -o $RETURNCODE = 2  ]
then
echo "Job RTC_67125_Master completed successfully"
else
echo "Job RTC_67125_Master aborting with Return Code :"$RETURNCODE
exit 3
fi;

