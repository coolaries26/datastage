#!/bin/sh

# Initialize environment variables to use the Datastage commands		                         #	
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

jobsDir=$1
. $1/varcreds.config
ds_project=$Datastage_Project-$Datastage_User-build
#ds_project=DI_DatastageDefault-2_0

echo "Connected to project: "$ds_project
echo "Running RTC_73636_Master job..."

#  Invoke Datastage job. 
$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_73636_ParamsUpd.txt $ds_project RTC_73636_Master_redesign > /dev/null  2>&1
RETURNCODE=$?
# Evaluating the return code								           #   
if [  $RETURNCODE = 1 -o $RETURNCODE = 2  ]
then 
echo "Job RTC_73636_Master completed successfully"
else
echo "Job RTC_73636_Master aborting with Return Code :"$RETURNCODE 
exit 3 
fi;
