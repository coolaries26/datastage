#!/bin/sh

# Initialize environment variables to use the Datastage commands                                         #
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

jobsDir=$1
idlMode=$2
. $1/varcreds.config
ds_project=$Datastage_Project-$Datastage_User-build
#ds_project=DI_DatastageDefault-2_0

## Defect 91496
if [[ `date` = *04:10:* ]];then
        idlMode=IDL
fi

RUNFAIL='RUN FA'
CRASHED='UNKNOW'
STOPPED='STOPPE'
RUNNING='RUNNIN'
RUNOK='RUN OK'
error_sev='SEVERE'
allSuccess=true



#orderJobs='RTC_82457_OrderCreateISTEntry RTC_82457_OrderRunISTCreate RTC_82457_OrderUpdateISTEntry RTC_82457_SalesOrder RTC_82457_Orders_Users RTC_82457_Orders_Contacts RTC_82457_Orders_Accounts RTC_82457_Orders_Leads'
orderJobs='IST_DB_OrderTime RTC_82457_OrderCreateISTEntry RTC_82457_OrderRunISTCreate RTC_82457_OrderUpdateISTEntry RTC_82457_SalesOrder'
mainSo='RTC_82457_Orders_Users RTC_82457_Orders_Contacts RTC_82457_Orders_Accounts RTC_82457_Orders_Leads'

ordRunning=false
	
for i in $orderJobs
do
	runstatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $i | grep "Job Status" | cut -c14-19`
        if [[ $runstatus = $RUNNING ]];then
		ordRunning=true
        fi
done

if [[ $ordRunning = 'true' ]];then
	echo `date` " <<< $ds_project: $JOBNAME currently running, try later"
        exit 3
fi

	
if [[  $idlMode = 'IDL' ]];then
        soTime='2000-01-01-00.00.00.000000'
        soCnt=5
else
		istDB=`cat $jobsDir/parmfiles/RTC_82457_ISTUpd.txt | grep IST_DB_ParamSet | grep ConnectionString | cut -d = -f 2`
		istUser=`cat $jobsDir/parmfiles/RTC_82457_ISTUpd.txt  | grep IST_DB_ParamSet | grep Username | cut -d = -f 2`
		istPwd=`cat $jobsDir/parmfiles/RTC_82457_ISTUpd.txt  | grep IST_DB_ParamSet | grep Password | cut -d = -f 2`
		db2 connect to $istDB user $istUser using $istPwd
		#if [[ -e $jobsDir/82457TimeZoneDiff.dontdelete ]]; then
			#soTime=`db2 -x "select timeprocessed - $timeDiff_82457 hours from di.integration_status where msgid = 'RTC_82457_Orders' and (status = 'Success' or status = 'Partial Success') order by timeprocessed desc fetch first row only"`
		#else
			soTime=`db2 -x "select TIMESTAMPREQUEST from di.integration_status where msgid = 'RTC_82457_Orders' and (status = 'Success' or status = 'Partial Success') order by timeprocessed desc fetch first row only"`
		#fi	
		
		db2 connect reset
		
		#If first time, set a fake time to pick all rows
		if [[ $soTime -eq '' ]];then 
			soTime='2000-01-01-00.00.00.000000'
		fi
		
		
		scDB=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep ConnectionString | cut -d = -f 2`
		scUser=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep Username | cut -d = -f 2`
		scPwd=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep Password | cut -d = -f 2`
		db2 connect to $scDB user $scUser using $scPwd
		soCnt=`db2 -x "select count from dsw.sales_order where last_updating_system_date >  timestamp('$soTime')"`
		soDSW=`db2 -x "select count from dsw.sales_order "`
		soSCT=`db2 -x "select count from sctid.ibm_sales_orders"`
		db2 connect reset 
		
		
		echo "Last time orders was processed is :  $soTime" 
		echo "# of Orders changed :  $soCnt " 
		echo "# of Orders  in DSW  :  $soDSW " 
		echo "# of Orders  in SCTID  :  $soSCT " 
fi


if [[ $soCnt -ne 0 || $soDSW -ne $soSCT  ]];then
	# reset job if necessary
	for i in $orderJobs
	do
		runstatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $i | grep "Job Status" | cut -c14-19`
  		if [[ $runstatus = $RUNFAIL || $runstatus = $STOPPED || $runstatus = $CRASHED ]]; then
    			$DSHOME/bin/dsjob -run -mode RESET $ds_project $i
  		fi
	done


 	echo "Ready to run IST job"
   
	#$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_ISTUpd.txt $ds_project IST_DB_OrderTime > /dev/null  2>&1
	#if  [[  ! -s  /var/datastage/data/RTC_82457_Orders/current/istOrderLastRun.csv ]];then
	#	echo "2000-01-01-00.00.00.000000" > /var/datastage/data/RTC_82457_Orders/current/istOrderLastRun.csv
	#fi
 	#sed -e "s/Ist_TimeStamp=/Ist_TimeStamp=$(cat /var/datastage/data/RTC_82457_Orders/current/istOrderLastRun.csv | cut -d \" -f 2 | sed -e 's/ /-/' -e 's/:/./g' )/" $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt  > $jobsDir/parmfiles/RTC_82457_OrdersUpd2.txt
 	sed -e "s/Ist_TimeStamp=/Ist_TimeStamp=$soTime/" $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt  > $jobsDir/parmfiles/RTC_82457_OrdersUpd2.txt
 
        if [[ ( $soDSW -gt  $soSCT ) && $soCnt -eq 0 ]];then
                #  Edge case scenario, what if a new row came in when data was processing. 
                #  Cannot determine this if a row was updated
                sed -e "s/Ist_TimeStamp=/Ist_TimeStamp=2000-01-01-00.00.00.000000/" $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt  > $jobsDir/parmfiles/RTC_82457_OrdersUpd2.txt
        fi
 	
  
	echo "Ready to run Orders  job"
   	$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_ISTUpd.txt $ds_project RTC_82457_OrderRunISTCreate > /dev/null  2>&1
	$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_OrdersUpd2.txt $ds_project RTC_82457_SalesOrder > /dev/null  2>&1
   	$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_ISTUpd.txt $ds_project RTC_82457_OrderUpdateISTEntry > /dev/null  2>&1
else
        echo "DONE...No updates on : " `date` 

fi


                        
                        
