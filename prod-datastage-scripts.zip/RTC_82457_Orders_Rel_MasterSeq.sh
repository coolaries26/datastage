#!/bin/sh

# Initialize environment variables to use the Datastage commands                                         #
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

jobsDir=$1
. $1/varcreds.config
ds_project=$Datastage_Project-$Datastage_User-build
#ds_project=DI_DatastageDefault-2_0

RUNFAIL='RUN FA'
CRASHED='UNKNOW'
STOPPED='STOPPE'
RUNNING='RUNNIN'
RUNOK='RUN OK'
error_sev='SEVERE'
allSuccess=true
host=`hostname`

mainSo='RTC_82457_Orders_Users RTC_82457_Orders_Contacts RTC_82457_Orders_Accounts RTC_82457_Orders_Leads'
allSo='RTC_82457_SalesOrder RTC_82457_Orders_Users RTC_82457_Orders_Contacts RTC_82457_Orders_Accounts RTC_82457_Orders_Leads'

ordRelRunning=false
	
for i in $allSo
do
	runstatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $i | grep "Job Status" | cut -c14-19`
        if [[ $runstatus = $RUNNING ]];then
		ordRelRunning=true
        fi
done

if [[ $ordRelRunning = 'true' ]];then
	echo `date` " <<< $ds_project: ORDERS Relationship job currently running, try later"
        exit 3
fi


if [[ -s $jobsDir/soRelRunTime.log ]];then
        scDB=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep ConnectionString | cut -d = -f 2`
        scUser=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep Username | cut -d = -f 2`
        scPwd=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep Password | cut -d = -f 2`
        tstmp=`cat $jobsDir/soRelRunTime.log`
        db2 connect to $scDB user $scUser using $scPwd
        soCnt=`db2 -x "select count from dsw.sales_order where last_updating_system_date >=  '$tstmp'"`
	db2 connect reset
else
        soCnt=5 #Probably first time run, arbitary number to invoke relationship job run
fi

echo "Count is $soCnt"

if [[ $soCnt -ne 0 ]];then
	# reset job if necessary
	for i in $mainSo
	do
		runstatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $i | grep "Job Status" | cut -c14-19`
  		if [[ $runstatus = $RUNFAIL || $runstatus = $STOPPED || $runstatus = $CRASHED ]]; then
    			$DSHOME/bin/dsjob -run -mode RESET $ds_project $i
  		fi
	done

	echo "Ready to run Orders  Relationship job"
	for i in  $mainSo
	do
		$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_OrdersRelUpd.txt $ds_project $i > /dev/null  2>&1
	done

       #####  Manual Check to see if any issues
        for job in $mainSo
        do
              indStatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $job | grep "Job Status" | cut -c14-19`
              error_body="$job under $host had failure around `date` , please investigate"
              error_subject="$job on $host failed"
                if [[ $indStatus = $RUNFAIL || $indStatus = $STOPPED || $indStatus = $CRASHED ]]; then
                     $DSHOME/bin/dsjob -logdetail $ds_project $job  -wave 0 > $jobsDir/../data/RTC_82457_Orders/$job.err
                	 errLog=`cat $jobsDir/../data/RTC_82457_Orders/$job.err | grep -E 'Fatal Error|SQLSTATE'`
                     if [[ !  -e  /tmp/rtc_82457_Orders.failed ]];then
                           echo "$error_body \n $errLog" |  mail -s "$error_sev: $error_subject" $email_id_82457
                     fi
                     allSuccess=false
                fi
       done
       if [[ $allSuccess = false ]];then
                touch /tmp/rtc_82457_Orders.failed
       fi
       if [[ $allSuccess = true  &&   -e  /tmp/rtc_82457_Orders.failed ]];then
                rm /tmp/rtc_82457_Orders.failed  > /dev/null
       fi


		####   WHEN TO RUN THE JOB
        ####   Store the db timestamp after job is complete, compare with next time run
        scDB=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep ConnectionString | cut -d = -f 2`
        scUser=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep Username | cut -d = -f 2`
        scPwd=`cat $jobsDir/parmfiles/RTC_82457_OrdersUpd.txt | grep SC_DB_ParamSet | grep Password | cut -d = -f 2`
        db2 connect to $scDB user $scUser using $scPwd
        		#if [[ -e $jobsDir/82457TimeZoneDiff.dontdelete ]]; then
                	#db2 -x "values current timestamp - $timeDiff_82457 hours " >  $jobsDir/soRelRunTime.log
                #else
                	db2 -x "values current timestamp - current timezone " >  $jobsDir/soRelRunTime.log
                #fi
        db2 connect reset

else
        echo "No updates for Orders relationship tables on : " `date`

fi


                        
                        
