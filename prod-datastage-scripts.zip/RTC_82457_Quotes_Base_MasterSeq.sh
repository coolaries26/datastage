#!/bin/sh

# Initialize environment variables to use the Datastage commands                                         #
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

jobsDir=$1
idlMode=$2
. $1/varcreds.config
ds_project=$Datastage_Project-$Datastage_User-build
#ds_project=DI_DatastageDefault-2_0

## Defect 91496
if [[ `date` = *04:15:* ]];then
        idlMode=IDL
fi

RUNFAIL='RUN FA'
CRASHED='UNKNOW'
STOPPED='STOPPE'
RUNNING='RUNNIN'
RUNOK='RUN OK'
error_sev='SEVERE'
allSuccess=true

#quoteJobs='RTC_82457_CreateISTEntry RTC_82457_RunISTCreate RTC_82457_UpdateISTEntry RTC_82457_Quotes RTC_82457_Quotes_Accounts RTC_82457_Quotes_Contacts RTC_82457_Quotes_Users'
quoteJobs='RTC_82457_CreateISTEntry RTC_82457_RunISTCreate RTC_82457_UpdateISTEntry IST_DB_QuoteTime RTC_82457_Quotes'
mainQt='RTC_82457_Quotes_Accounts RTC_82457_Quotes_Contacts RTC_82457_Quotes_Users'


qtRunning=false

for i in $quoteJobs
do
        runstatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $i | grep "Job Status" | cut -c14-19`
        if [[ $runstatus = $RUNNING ]];then
                qtRunning=true
        fi
done

echo "qtRunning is $qtRunning"

if [[ $qtRunning = 'true' ]];then
        echo `date` " <<< $ds_project: $JOBNAME currently running, try later"
        exit 3
fi

if [[  $idlMode = 'IDL' ]];then
        qtTime='2000-01-01-00.00.00.000000'
        qtCnt=5
else
		istDB=`cat $jobsDir/parmfiles/RTC_82457_ISTUpd.txt | grep IST_DB_ParamSet | grep ConnectionString | cut -d = -f 2`
		istUser=`cat $jobsDir/parmfiles/RTC_82457_ISTUpd.txt  | grep IST_DB_ParamSet | grep Username | cut -d = -f 2`
		istPwd=`cat $jobsDir/parmfiles/RTC_82457_ISTUpd.txt  | grep IST_DB_ParamSet | grep Password | cut -d = -f 2`
		db2 connect to $istDB user $istUser using $istPwd
		#if [[ -e $jobsDir/82457TimeZoneDiff.dontdelete ]]; then
			#qtTime=`db2 -x "select timeprocessed  - $timeDiff_82457 hours from di.integration_status where msgid = 'RTC_82457_Quotes' and (status = 'Success' or status = 'Partial Success') order by timeprocessed desc fetch first row only"`
		#else
			## Defect 91496
			qtTime=`db2 -x "select TIMESTAMPREQUEST  from di.integration_status where msgid = 'RTC_82457_Quotes' and (status = 'Success' or status = 'Partial Success') order by timeprocessed desc fetch first row only"`	
		#fi
		
		db2 connect reset
		
		#If first time, set a fake time to pick all rows
		if [[ $qtTime -eq '' ]];then 
			qtTime='2000-01-01-00.00.00.000000'
		fi
		
		
		scDB=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep ConnectionString | cut -d = -f 2`
		scUser=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep Username | cut -d = -f 2`
		scPwd=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep Password | cut -d = -f 2`
		db2 connect to $scDB user $scUser using $scPwd
		qtCnt=`db2 -x "select count from dsw.quotes where last_updating_system_date >=  timestamp('$qtTime')"`
		qtDSW=`db2 -x "select count from dsw.quotes "`
		qtSCT=`db2 -x "select count from sctid.ibm_quotes"`
		db2 connect reset 
		
		echo "Last time quotes was processed is : $qtTime"
		echo "# of quotes changed :  $qtCnt "
		echo "# of quotes in DSW  :  $qtDSW " 
		echo "# of quotes in SCTID :  $qtSCT " 
fi


if [[ $qtCnt -ne 0 ||  $qtDSW -ne $qtSCT  ]];then

	# reset job if necessary
	for i in $quoteJobs
	do
		runstatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $i | grep "Job Status" | cut -c14-19`
  		if [[ $runstatus = $RUNFAIL || $runstatus = $STOPPED || $runstatus = $CRASHED ]]; then
    			$DSHOME/bin/dsjob -run -mode RESET $ds_project $i
  		fi
	done


	
 	echo "Ready to run IST job to determine last successful time "
    	#  Invoke Datastage job.
		#$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_ISTUpd.txt $ds_project IST_DB_QuoteTime > /dev/null  2>&1
		#if  [[  ! -s /var/datastage/data/RTC_82457_Quotes/current/istQuotesLastRun.csv ]] ;then
		#	echo "2000-01-01-00.00.00.000000" > /var/datastage/data/RTC_82457_Quotes/current/istQuotesLastRun.csv
		#fi
		#sed -e "s/Ist_TimeStamp=/Ist_TimeStamp=$(cat /var/datastage/data/RTC_82457_Quotes/current/istQuotesLastRun.csv | cut -d \" -f 2 | sed -e 's/ /-/' -e 's/:/./g' )/" $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt  > $jobsDir/parmfiles/RTC_82457_QuotesUpd2.txt
		sed -e "s/Ist_TimeStamp=/Ist_TimeStamp=$qtTime/" $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt  > $jobsDir/parmfiles/RTC_82457_QuotesUpd2.txt
		
	    if [[ ( $qtDSW -gt  $qtSCT ) && $qtCnt -eq 0 ]];then
               #  Edge case scenario, what if a new row came in when data was processing. 
               #  Cannot determine this if a row was updated
               sed -e "s/Ist_TimeStamp=/Ist_TimeStamp=2000-01-01-00.00.00.000000/" $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt  > $jobsDir/parmfiles/RTC_82457_QuotesUpd2.txt
        fi
	

	echo "Ready to run Quotes  job"
	$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_ISTUpd.txt $ds_project RTC_82457_RunISTCreate  > /dev/null  2>&1
	$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_QuotesUpd2.txt $ds_project RTC_82457_Quotes  > /dev/null  2>&1
	$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_ISTUpd.txt $ds_project RTC_82457_UpdateISTEntry  > /dev/null  2>&1
	
else
	echo "DONE...No updates on : " `date`  
fi
                        
