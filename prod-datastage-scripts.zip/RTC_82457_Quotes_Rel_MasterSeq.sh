#!/bin/sh

# Initialize environment variables to use the Datastage commands                                         
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

jobsDir=$1
. $1/varcreds.config
ds_project=$Datastage_Project-$Datastage_User-build
#ds_project=DI_DatastageDefault-2_0

RUNFAIL='RUN FA'
CRASHED='UNKNOW'
STOPPED='STOPPE'
RUNNING='RUNNIN'
RUNOK='RUN OK'
error_sev='SEVERE'
allSuccess=true


##quoteJobs='RTC_82457_CreateISTEntry RTC_82457_RunISTCreate RTC_82457_UpdateISTEntry RTC_82457_Quotes RTC_82457_Quotes_Accounts RTC_82457_Quotes_Contacts RTC_82457_Quotes_Users'
mainQt='RTC_82457_Quotes_Accounts RTC_82457_Quotes_Contacts RTC_82457_Quotes_Users'
allQt='RTC_82457_Quotes RTC_82457_Quotes_Accounts RTC_82457_Quotes_Contacts RTC_82457_Quotes_Users'
host=`hostname`

qtRelRunning=false

for i in $allQt
do
        runstatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $i | grep "Job Status" | cut -c14-19`
        if [[ $runstatus = $RUNNING ]];then
                qtRelRunning=true
        fi
done

echo "qtRelRunning is $qtRelRunning"

if [[ $qtRelRunning = 'true' ]];then
        echo `date` " <<< $ds_project: $JOBNAME currently running, try later"
        exit 3
fi

if [[ -s $jobsDir/qtRelRunTime.log ]];then
	scDB=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep ConnectionString | cut -d = -f 2`
	scUser=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep Username | cut -d = -f 2`
	scPwd=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep Password | cut -d = -f 2`
	tstmp=`cat $jobsDir/qtRelRunTime.log`
	db2 connect to $scDB user $scUser using $scPwd
	qtCnt=`db2 -x "select count from dsw.quotes where last_updating_system_date >=  '$tstmp'"`
	db2 connect reset 
else
	qtCnt=5 #Probably first time run, arbitary number to invoke relationship job run
fi

echo "qtCnt is $qtCnt"


if [[ $qtCnt -ne 0 ]];then
	# reset job if necessary
	for i in $mainQt
	do
		runstatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $i | grep "Job Status" | cut -c14-19`
  		if [[ $runstatus = $RUNFAIL || $runstatus = $STOPPED || $runstatus = $CRASHED ]]; then
    			$DSHOME/bin/dsjob -run -mode RESET $ds_project $i
  		fi
	done

	echo "Ready to run Quotes  Relationship job"

	for i in  $mainQt
	do
   		$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_82457_QuotesRelUpd.txt $ds_project $i  > /dev/null  2>&1
	done


	#####  Manual Check to see if any issues 
        for job in $mainQt
        do
              indStatus=`$DSHOME/bin/dsjob -jobinfo $ds_project $job | grep "Job Status" | cut -c14-19`
              error_body="$job under $host had failure around `date` , please investigate"
              error_subject="$job on $host failed"
                if [[ $indStatus = $RUNFAIL || $indStatus = $STOPPED || $indStatus = $CRASHED ]]; then
                     $DSHOME/bin/dsjob -logdetail $ds_project $job  -wave 0 > $jobsDir/../data/RTC_82457_Quotes/$job.err
                	 errLog=`cat $jobsDir/../data/RTC_82457_Quotes/$job.err | grep -E 'Fatal Error|SQLSTATE'`
                     if [[ !  -e  /tmp/rtc_82457_Quotes.failed ]];then
                            echo "$error_body \n $errLog" |  mail -s "$error_sev: $error_subject" $email_id_82457
                     fi
                     allSuccess=false
                fi
       done
       if [[ $allSuccess = false ]];then
                touch /tmp/rtc_82457_Quotes.failed
       fi
       if [[ $allSuccess = true  &&   -e  /tmp/rtc_82457_Quotes.failed ]];then
                rm /tmp/rtc_82457_Quotes.failed  > /dev/null
       fi


	####   WHEN TO RUN THE JOB
	####   Store the db timestamp after job is complete, compare with next time run
	scDB=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep ConnectionString | cut -d = -f 2`
	scUser=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep Username | cut -d = -f 2`
	scPwd=`cat $jobsDir/parmfiles/RTC_82457_QuotesUpd.txt | grep SC_DB_ParamSet | grep Password | cut -d = -f 2`
	db2 connect to $scDB user $scUser using $scPwd
				#if [[ -e $jobsDir/82457TimeZoneDiff.dontdelete ]]; then
                	#db2 -x "values current timestamp - $timeDiff_82457 hours " >  $jobsDir/qtRelRunTime.log
                #else
                	db2 -x "values current timestamp - current timezone " >  $jobsDir/qtRelRunTime.log
                #fi
	db2 connect reset
		
else
	echo "No updates for Quotes Relationships on : " `date`
fi
                        
