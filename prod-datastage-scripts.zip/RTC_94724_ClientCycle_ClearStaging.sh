#!/bin/sh


# Initialize environment variables to use the Datastage commands                                         #
cd `cat /.dshome`
. ./dsenv > /dev/null 2>&1

jobsDir=$1
. $1/varcreds.config
ds_project=$Datastage_Project-$Datastage_User-build
#ds_project=DI_DatastageDefault-2_0

echo "Connected to project: "$ds_project
echo "Running RTC_94724_ClientCycle_ClearStaging job..."

#  Invoke Datastage job.
$DSHOME/bin/dsjob -run -jobstatus -warn 0 -paramfile $jobsDir/parmfiles/RTC_94724_ParamsUpd.txt $ds_project RTC_94724_ClientCycle_ClearStaging > /dev/null  2>&1
RETURNCODE=$?
# Evaluating the return code                                                                       #
if [  $RETURNCODE = 1 -o $RETURNCODE = 2  ]
then
echo "Job RTC_94724_ClientCycle_ClearStaging completed successfully"
else
echo "Job RTC_94724_ClientCycle_ClearStaging aborting with Return Code :"$RETURNCODE
exit 3
fi;

