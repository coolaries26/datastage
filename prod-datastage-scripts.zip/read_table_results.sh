#!/bin/bash

jobdatadir=$1
statusfile=$jobdatadir"/status.txt"
resultsfile=$jobdatadir"/table_results.csv"

while read line
do
status=$line
done <$statusfile

status_string="Unknown"

if [ "$status" = "1" ]
then
   status_string="Success"
elif [ "$status" = "2" ]
then
   status_string="Warning"
   error_message="A warning occurred while running the job.  See log files in $jobdatadir for details."
elif [ "$status" = "3" ]
then
   status_string="Failure"
   error_message="An error occurred while running the job.  See log files in $jobdatadir for details."
fi

isFirst=1

payload="{\"Tables\":{\"Table\":["
while read line
do
  index=0
  
  OIFS=$IFS
  IFS=','
  arr=$line
  for x in $arr
  do
    if [ "$index" = 0 ]
    then
      name=$x
    elif [ "$index" = 1 ]
    then
      description=$x
    elif [ "$index" = 2 ]
    then
      operation=$x
    elif [ "$index" = 3 ]
    then
      expected=$x
    elif [ "$index" = 4 ]
    then
      success=$x
    elif [ "$index" = 5 ]
    then
      failure=$x
    fi
    index=$(( $index + 1 ))
  done
  
  if [ "$isFirst" = 1 ] 
  then
    isFirst=0;
  else
     payload=$payload","
  fi

  if [ "$success" = "NONE" ]
  then
    if [ "$failure" != "NONE" ] && [ "$expected" != "NONE" ] && [ "$status" != "3" ]
    then 
       echo $expected
       echo $failure
       success=`expr $expected - $failure`
    fi
  fi

  if [ "$status" = "1" ] && [ "$expected" != "NONE" ]
  then
    if [ "$failure" = "$expected" ] && [ "$expected" != "0" ]
    then
       status=3
       status_string="Failure"
       error_message="There were no records updated.  See log files in $jobdatadir for details."
    elif [ "$success" != "$expected" ] && [ "$success" != "NONE" ] 
    then
       status=4
       status_string="Partial Success"
    fi
  elif [ "$status" = "2" ] && [ "$expected" != "NONE" ]
  then
    if [ "$failure" = "$expected" ] && [ "$expected" != "0" ]
    then
       status=3
       status_string="Failure"
       error_message="There were no records updated.  See log files in $jobdatadir for details."
    fi
  fi
  
  
  payload=$payload"{\"name\": \"$name\", \"description\": \"$description\", \"operation\": \"$operation\", \"expected\": \"$expected\", \"success\": \"$success\", \"failure\": \"$failure\"}"
  
  for x in $arr
  do
    echo "> [$x]"
  done
  IFS=$OIFS
  
done <$resultsfile

payload=$payload"]}}"

echo \'$status_string\',\'$error_message\',\'$payload\' > $jobdatadir"/final_ist_entry.csv"
echo $payload


